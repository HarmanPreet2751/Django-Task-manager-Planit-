from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('pricing/', views.pricing_view, name='pricing'),
    path('user-details/', views.user_details_view, name='user_details'),
    path('file-manager/', views.file_manager, name='file_manager'),
    path('file/<int:file_id>/', views.serve_file, name='serve_file'),
    path('file/delete/<int:file_id>/', views.delete_file, name='delete_file'),
    path('api/login/', views.login_user, name='login_user'),
    path('api/register/', views.register_user, name='register_user'),
    path('api/send-otp/', views.send_otp, name='send_otp'),
    path('api/check-username/', views.check_username, name='check_username'),
    path('api/add-task/', views.add_task, name='add_task'),
    path('api/delete-task/', views.delete_task, name='delete_task'),
    path('api/update-task/', views.update_task, name='update_task'),
]